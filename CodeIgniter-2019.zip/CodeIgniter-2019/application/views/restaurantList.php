<div class="card-deck">
  <div class="card border-0 p-3" style="cursor:pointer;">
    <img src="https://images.otstatic.com/prod/26459672/12/medium.jpg" class="card-img-top" style="width:100%;height:200px">
    <div class="card-body p-0 mt-2">
      <h6 class="card-title mb-0">Cano</h6>
      <small class="text-muted">Snacks, Fast Food, American</small>
      <ul class="list-group list-group-horizontal mb-0">
        <li class="list-group-item border-0 pl-0">
        <span class="badge badge-success"><i class="fa fa-star"></i> 4.1</span>
        </li>
        <li class="list-group-item border-0">
            <small><i class="fa fa-clock-o"></i> 34 MINS</small>
        </li>
        <li class="list-group-item border-0">
            <small><b class="text-muted">₹150.00</b></small>
        </li>
      </ul>
    </div>
    <div class="text-center mb-0" style="margin-top:-10px;">
        <hr>
      <a class="font-weight-bold border-0 text-decoration-none text-primary" href="#" data-toggle="modal" data-target="#exampleModalCenter">QUICK VIEW</a>
    </div>
  </div>
  <div class="card border-0 p-3" style="cursor:pointer;">
    <img src="https://comfortinnstjerome.com/wp-content/uploads/2018/12/ComfortInn-Scores.jpg" class="card-img-top" style="width:100%;height:200px">
    <div class="card-body p-0 mt-2">
      <h6 class="card-title mb-0">Scores</h6>
      <small class="text-muted">North Indian, South Indian, Continental, Thalis</small>
      <ul class="list-group list-group-horizontal mb-0">
        <li class="list-group-item border-0 pl-0">
        <span class="badge badge-success"><i class="fa fa-star"></i> 4.1</span>
        </li>
        <li class="list-group-item border-0">
            <small><i class="fa fa-clock-o"></i> 34 MINS</small>
        </li>
        <li class="list-group-item border-0">
            <small><b class="text-muted">₹150.00</b></small>
        </li>
      </ul>
    </div>
    <div class="text-center mb-0" style="margin-top:-10px;">
        <hr>
      <a class="font-weight-bold border-0 text-decoration-none text-primary" href="#">QUICK VIEW</a>
    </div>
  </div>
  <div class="card border-0 p-3" style="cursor:pointer;">
    <img src="https://content1.jdmagicbox.com/comp/jalandhar/k4/0181px181.x181.180615220821.y1k4/catalogue/caldo-s-pizza-and-cafe-jalandhar-home-delivery-restaurants-j5oNIRucqv.jpg" class="card-img-top" style="width:100%;height:200px">
    <div class="card-body p-0 mt-2">
      <h6 class="card-title mb-0">CP (Crown's Pizza)</h6>
      <small class="text-muted">North Indian</small>
      <ul class="list-group list-group-horizontal mb-0">
        <li class="list-group-item border-0 pl-0">
        <span class="badge badge-success"><i class="fa fa-star"></i> 4.1</span>
        </li>
        <li class="list-group-item border-0">
            <small><i class="fa fa-clock-o"></i> 34 MINS</small>
        </li>
        <li class="list-group-item border-0">
            <small><b class="text-muted">₹150.00</b></small>
        </li>
      </ul>
    </div>
    <div class="text-center mb-0" style="margin-top:-10px;">
        <hr>
      <a class="font-weight-bold border-0 text-decoration-none text-primary" href="#">QUICK VIEW</a>
    </div>
  </div>
  <div class="card border-0 p-3" style="cursor:pointer;">
    <img src="https://content1.jdmagicbox.com/comp/palghar/p9/022pxx22.xx22.171114172602.f3p9/catalogue/pizzeria-palghar-1og9rb6upq.jpg" class="card-img-top" style="width:100%;height:200px">
    <div class="card-body p-0 mt-2">
      <h6 class="card-title mb-0">Pizzeria Pure Veg</h6>
      <small class="text-muted">Bakery, Fast Food, Desserts, Combo</small>
      <ul class="list-group list-group-horizontal mb-0">
        <li class="list-group-item border-0 pl-0">
        <span class="badge badge-success"><i class="fa fa-star"></i> 4.1</span>
        </li>
        <li class="list-group-item border-0">
            <small><i class="fa fa-clock-o"></i> 34 MINS</small>
        </li>
        <li class="list-group-item border-0">
            <small><b class="text-muted">₹150.00</b></small>
        </li>
      </ul>
    </div>
    <div class="text-center mb-0" style="margin-top:-10px;">
        <hr>
      <a class="font-weight-bold border-0 text-decoration-none text-primary" href="#">QUICK VIEW</a>
    </div>
  </div>
</div><br>















<!-- Button trigger modal -->
<!-- <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModalCenter">
  Launch demo modal
</button> -->

<!-- Modal -->
<div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title text-uppercase" id="exampleModalCenterTitle"><i class="fa fa-spoon"></i> cano's MENU</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        
      <div class="card-deck">
  <div class="card border-0 p-0 cursor-pointer">
    <img src="https://res.cloudinary.com/swiggy/image/upload/fl_lossy,f_auto,q_auto,w_508,h_320,c_fill/bfsjo1zah5pfmn18luj9" class="card-img-top" alt="...">
    <div class="card-body p-0">
      <p class="card-title">Masala dosa</p>
    </div>
  </div>
  <div class="card border-0 p-0 cursor-pointer">
    <img src="https://res.cloudinary.com/swiggy/image/upload/fl_lossy,f_auto,q_auto,w_508,h_320,c_fill/djva8dpzvhz1dtjl8aff" class="card-img-top" alt="...">
    <div class="card-body p-0">
      <p class="card-title">Chole Bhatoora</p>
    </div>
  </div>
  <div class="card border-0 p-0 cursor-pointer">
    <img src="https://res.cloudinary.com/swiggy/image/upload/fl_lossy,f_auto,q_auto,w_508,h_320,c_fill/avnobvtyekqwnxnjqloi" class="card-img-top" alt="...">
    <div class="card-body p-0">
      <p class="card-title">Lachcha paratha</p>
    </div>
  </div>
  </div>

      </div>

      <div class="modal-footer">
      <a class="font-weight-bold border-0 text-decoration-none text-primary" href="#">More</a>
      </div>

    </div>
  </div>
</div>