
<!-- Navigation -->
<nav class="navbar navbar-drak bg-black shadow">
	<a class="navbar-brand" href="#">
		<img src="<?php echo base_url('assets/images/foodmagic-logo.png'); ?>" width="200" height="40" alt="foodmagic" title="foodmagic">
		
	</a>
	<div class="justify-content-end d-block d-sm-none">
		<h3 href="#nav" onclick="openNav()" style="color: #FFBE0D;cursor: pointer;"> &#9776;</h3>
	</div>
	<div class="d-none d-sm-block">
		<ul class="nav justify-content-end" id="myTab" role="tablist">
			<!-- <li class="nav-item">
          <a class="nav-link text-uppercase" href="#">Contact Us</a>
        </li>
        <li class="nav-item">
          <a class="nav-link text-uppercase" href="#">terms & conditions</a>
        </li>
        <li class="nav-item">
          <a class="nav-link text-uppercase" href="#">Help (faq's)</a>
        </li>
        <li class="nav-item">
          <a class="nav-link text-uppercase" href="#">privacy policy</a>
        </li>
        <li class="nav-item">
          <a class="nav-link text-uppercase" href="#">About Us</a>
        </li> -->

			<!-- Optional -->
			<li class="nav-item">
				<!-- <a class="nav-link" href="#Login" id="#Login">Sign Up/Log In</a> -->
				<!-- <button class="btn btn-primary menu-custom-btn" data-toggle="modal"
					data-target="#exampleModalCenter">Sign Up</button> -->
				<button class="btn btn-primary menu-custom-btn mx-3" data-toggle="modal"
					data-target="#login">Login</button>
			</li>
			<h3 href="#nav" onclick="openNav()" style="color: #FFBE0D;cursor: pointer;"> &#9776;</h3>
		</ul>
	</div>
</nav>
<!-- //Navigation -->

<!-- Side Navigation -->
<div id="mySidenav" class="sidenav text-center" style="background-color: #333333;height: 100vh;">
	<a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
	<a class="nav-link text-uppercase my-4" href="#">Contact Us</a>
	<a class="nav-link text-uppercase my-4" href="#">terms & conditions</a>
	<a class="nav-link text-uppercase my-4" href="#">Help (faq's)</a>
	<a class="nav-link text-uppercase my-4" href="#">privacy policy</a>
	<a class="nav-link text-uppercase my-4" href="#">About Us</a>

	<!-- <a class="nav-link text-uppercase my-3" href="#LogOut" id="#LogOut">Log Out</a> -->
	<a class="nav-link text-uppercase my-3" href="#LogIn" data-toggle="modal" data-target="#login">Login</a>
</div>
<!-- Side Navigation -->

<!-- //Navigation -->