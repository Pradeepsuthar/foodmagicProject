<div class="jumbotron jumbotron-fluid bg-jumbotron">
	<div class="container my-5" style="position: absolute;top:50%;left: 50%;transform: translate(-50%,-50%)">
		<h2 class="text-center text-uppercase" style="font-size: 50px"><b>SIGNUP & order your favourite food on
				food<span style="color: #FFBE0D">magic</span></b></h2>
		<p class="text-center text-capitalize" style="font-size: 25px;font-weight: bold;">this is our college mini project 2019</p>

		<div class="submit-btn text-center my-5">
			<!-- <button class="btn btn-primary custom-btn btn-lg mx-2 my-2" data-toggle="modal"
				data-target="#exampleModalCenter">Sign Up</button> -->
			<!-- <button class="btn btn-primary custom-btn btn-lg" data-toggle="modal"
				data-target="#exampleModalCenter">Login</button> -->
		</div>

		<!-- search-food -->
		<!-- <div class="search-food">
		<div class="search-bar">
		  <input class="search-input" type="text" placeholder="Type delivery location here...">
		</div>
	  </div>
	  <div class="submit-btn text-center my-5">
		<button class="btn btn-primary custom-btn btn-lg">FIND FOOD</button>
	  </div> -->
	</div>
</div>