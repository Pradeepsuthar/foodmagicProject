<div class="card card-deck p-auto m-auto d-flex justify-content-around">
  
  <a href="#">
  <figure class="figure p-3 text-center">
  <img src="https://b.zmtcdn.com/images/search_tokens/app_icons/category_8.png?output-format=webp" class="figure-img img-fluid rounded" style="width:50px;height:50px;">
  <figcaption class="figure-caption">Breakfast</figcaption>
</figure>
</a>

<a href="#">
  <figure class="figure p-3 text-center">
  <img src="https://b.zmtcdn.com/images/search_tokens/app_icons/category_9.png?output-format=webp" class="figure-img img-fluid rounded" style="width:50px;height:50px;">
  <figcaption class="figure-caption">Lunch</figcaption>
</figure>
</a>

<a href="#">
  <figure class="figure p-3 text-center">
  <img src="https://b.zmtcdn.com/images/search_tokens/app_icons/category_10.png?output-format=webp" class="figure-img img-fluid rounded" style="width:50px;height:50px;">
  <figcaption class="figure-caption">Dinner</figcaption>
</figure>
</a>

<a href="#">
  <figure class="figure p-3 text-center">
  <img src="https://b.zmtcdn.com/images/search_tokens/app_icons/category_3.png?output-format=webp" class="figure-img img-fluid rounded" style="width:50px;height:50px;">
  <figcaption class="figure-caption">Drinks</figcaption>
</figure>
</a>

<a href="#">
  <figure class="figure p-3 text-center">
  <img src="https://b.zmtcdn.com/images/search_tokens/app_icons/category_1.png?output-format=webp" class="figure-img img-fluid rounded" style="width:50px;height:50px;">
  <figcaption class="figure-caption">Fast Food</figcaption>
</figure>
</a>

<a href="#">
  <figure class="figure p-3 text-center">
  <img src="https://b.zmtcdn.com/images/search_tokens/app_icons/category_9.png?output-format=webp" class="figure-img img-fluid rounded" style="width:50px;height:50px;">
  <figcaption class="figure-caption">Street Food</figcaption>
</figure>
</a>

<a href="#">
  <figure class="figure p-3 text-center">
  <img src="https://b.zmtcdn.com/images/search_tokens/app_icons/special_10.png?output-format=webp" class="figure-img img-fluid rounded" style="width:50px;height:50px;">
  <figcaption class="figure-caption">Desserts & Bakes</figcaption>
</figure>
</a>

</div>