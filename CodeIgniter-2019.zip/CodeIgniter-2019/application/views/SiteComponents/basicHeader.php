<!doctype html>
<html lang="en-IN">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <link href="<?php echo base_url('assets/images/favicon.gif'); ?>" rel="shortcut icon" type="image/x-icon" />
  <title>Order food online from GITS&#39;s best food delivery service. Order from restaurants near you</title>
  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">

  <!-- Custom CSS -->
  <link rel="stylesheet" href="<?php echo base_url('assets/css/style.css'); ?>">

  <!-- Custom JavaScript -->
  <script src="<?php echo base_url('assets/js/index.js'); ?>"></script>


  <!-- Font & Icons-->
  <link href="//maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
</head>

<body onload="foodmagicPreLoader()">
<!-- <body> -->
<!-- Preloader -->
        <div id="loader"></div>