
<div id="carouselExampleInterval" class="carousel slide d-none d-lg-block d-xl-block" data-ride="carousel" style="height:auto;padding:20px">
	<div class="carousel-inner">
		<div class="carousel-item active" data-interval="3000">
			<div class="row">
				<div class="col-3">
					<div class="card hvr" style="width: 18rem;height:288px">
						<img src="https://res.cloudinary.com/swiggy/image/upload/fl_lossy,f_auto,q_auto,w_520,h_520/rng/md/carousel/production/sehfwa8mi025idksweab"
							class="card-img-top" style="width: 18rem;height:288px">

					</div>
				</div>
				<div class="col-3">
					<div class="card" style="width: 18rem;height:288px">
						<img src="https://res.cloudinary.com/swiggy/image/upload/fl_lossy,f_auto,q_auto,w_520,h_520/rng/md/carousel/production/rxunzdce8mxdvxllf2q6"
							class="card-img-top" style="width: 18rem;height:288px">

					</div>
				</div>
				<div class="col-3">
					<div class="card" style="width: 18rem;height:288px">
						<img src="https://res.cloudinary.com/swiggy/image/upload/fl_lossy,f_auto,q_auto,w_520,h_520/rng/md/carousel/production/q3lzgx0qg1qhwrjcvas5"
							class="card-img-top" style="width: 18rem;height:288px">

					</div>
				</div>
				<div class="col-3">
					<div class="card" style="width: 18rem;height:288px">
						<img src="https://res.cloudinary.com/swiggy/image/upload/fl_lossy,f_auto,q_auto,w_520,h_520/marketing-dashboard/carousel/pya4c3wc5ncvwlesavqx"
							class="card-img-top" style="width: 18rem;height:288px">

					</div>
				</div>

			</div>
		</div>
		<div class="carousel-item" data-interval="3000">
			<div class="row">
				<div class="col-3">
					<div class="card" style="width: 18rem;height:288px">
						<img src="https://res.cloudinary.com/swiggy/image/upload/fl_lossy,f_auto,q_auto,w_520,h_520/k7f6xdk98ywjcochkcwm"
							class="card-img-top" style="width: 18rem;height:288px">

					</div>
				</div>
				<div class="col-3">
					<div class="card" style="width: 18rem;height:288px">
						<img src="https://res.cloudinary.com/swiggy/image/upload/fl_lossy,f_auto,q_auto,w_520,h_520/marketing-dashboard/carousel/e8qsywpath9uli7tnikc"
							class="card-img-top" style="width: 18rem;height:288px">

					</div>
				</div>
				<div class="col-3">
					<div class="card" style="width: 18rem;height:288px">
						<img src="https://res.cloudinary.com/swiggy/image/upload/fl_lossy,f_auto,q_auto,w_520,h_520/marketing-dashboard/carousel/bmp2yqaaqouptllxmkei"
							class="card-img-top" style="width: 18rem;height:288px">

					</div>
				</div>
				<div class="col-3">
					<div class="card" style="width: 18rem;height:288px">
						<img src="https://res.cloudinary.com/swiggy/image/upload/fl_lossy,f_auto,q_auto,w_520,h_520/rng/md/carousel/production/oov01vhlif8nvs4idkoc"
							class="card-img-top" style="width: 18rem;height:288px">

					</div>
				</div>

			</div>
		</div>
	</div>
	<a class="carousel-control-prev" href="#carouselExampleInterval" role="button" data-slide="prev">
        <div style="background-color:#fff;color:#48494a;padding:10px;border-radius:50%;font-size:25px">
        <span class="fa fa-long-arrow-left" aria-hidden="true" ></span>
        </div>
		
	</a>
	<a class="carousel-control-next" href="#carouselExampleInterval" role="button" data-slide="next">
    <div style="background-color:#fff;color:#48494a;padding:10px;border-radius:50%;font-size:25px">
        <span class="fa fa-long-arrow-right" aria-hidden="true" ></span>
        </div>
	</a>
</div>



<!-- mobile view -->

<div id="carouselExampleInterval" class="carousel slide d-block d-lg-none d-xl-none" data-ride="carousel" style="height:40vh;">
	<div class="carousel-inner">
	  <div class="carousel-item active" data-interval="2000">
		<img src="https://res.cloudinary.com/swiggy/image/upload/fl_lossy,f_auto,q_auto,w_520,h_520/rng/md/carousel/production/sehfwa8mi025idksweab" class="d-block w-100 h-50">
	  </div>
	  <div class="carousel-item" data-interval="2000">
		<img src="https://res.cloudinary.com/swiggy/image/upload/fl_lossy,f_auto,q_auto,w_520,h_520/rng/md/carousel/production/oov01vhlif8nvs4idkoc" class="d-block w-100 h-50">
	  </div>
	  <div class="carousel-item" data-interval="2000">
		<img src="https://res.cloudinary.com/swiggy/image/upload/fl_lossy,f_auto,q_auto,w_520,h_520/rng/md/carousel/production/s4aochfh0bsoa3m1y62y" class="d-block w-100 h-50">
	  </div>
	  <div class="carousel-item" data-interval="2000">
		<img src="https://res.cloudinary.com/swiggy/image/upload/fl_lossy,f_auto,q_auto,w_520,h_520/k7f6xdk98ywjcochkcwm" class="d-block w-100 h-50">
	  </div>
	  <div class="carousel-item" data-interval="2000">
		<img src="https://res.cloudinary.com/swiggy/image/upload/fl_lossy,f_auto,q_auto,w_520,h_520/marketing-dashboard/carousel/e8qsywpath9uli7tnikc" class="d-block w-100 h-50">
	  </div>
	  <div class="carousel-item" data-interval="2000">
		<img src="https://res.cloudinary.com/swiggy/image/upload/fl_lossy,f_auto,q_auto,w_520,h_520/marketing-dashboard/carousel/bmp2yqaaqouptllxmkei" class="d-block w-100 h-50">
	  </div>
	  <div class="carousel-item" data-interval="2000">
		<img src="https://res.cloudinary.com/swiggy/image/upload/fl_lossy,f_auto,q_auto,w_520,h_520/k7f6xdk98ywjcochkcwm" class="d-block w-100 h-50">
	  </div>
	  <div class="carousel-item" data-interval="2000">
		<img src="https://res.cloudinary.com/swiggy/image/upload/fl_lossy,f_auto,q_auto,w_520,h_520/rng/md/carousel/production/oov01vhlif8nvs4idkoc" class="d-block w-100 h-50">
	  </div>
	  <div class="carousel-item" data-interval="2000">
		<img src="https://res.cloudinary.com/swiggy/image/upload/fl_lossy,f_auto,q_auto,w_520,h_520/rng/md/carousel/production/s4aochfh0bsoa3m1y62y" class="d-block w-100 h-50">
	  </div>
	  <div class="carousel-item" data-interval="2000">
		<img src="https://res.cloudinary.com/swiggy/image/upload/fl_lossy,f_auto,q_auto,w_520,h_520/rng/md/carousel/production/s4aochfh0bsoa3m1y62y" class="d-block w-100 h-50">
	  </div>
	  <div class="carousel-item" data-interval="2000">
		<img src="https://res.cloudinary.com/swiggy/image/upload/fl_lossy,f_auto,q_auto,w_520,h_520/k7f6xdk98ywjcochkcwm" class="d-block w-100 h-50">
	  </div>
	</div>
  </div>