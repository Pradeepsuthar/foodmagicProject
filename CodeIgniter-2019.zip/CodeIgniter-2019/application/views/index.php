<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>

<?php include("SiteComponents/basicHeader.php"); ?>

<?php include("navigation.php"); ?>

<?php include("bannerHeader.php"); ?>

<div class="container-fluid p-3">
<h3 class="text-muted">Our Best Restaurants</h3>
<?php include("bannerSlider.php"); ?>
</div>

<div class="container p-3">
    <div class="clearfix">
    <h3 class="text-muted float-left">Near by Restaurants</h3>
    <form class="form-inline my-2 my-lg-0 float-right">
      <input class="input-filed mr-sm-2" type="search" placeholder="Search Restaurants" aria-label="Search">
    </form>
</div>
    <br>
<?php include("restaurantList.php"); ?>
</div>

<div class="container p-3">
    <div class="clearfix">
    <h3 class="text-muted float-left">Food</h3>
    </div>
    <br>
<?php include("foodList.php"); ?>
</div>

<div class="container p-3">
    <h3 class="text-muted">Quick Searches</h3><br>
    <?php include("categoriesSec.php"); ?>
</div>

<?php include("mainFooter.php"); ?>

<?php include("login-signUp.php"); ?>


<?php include("SiteComponents/basicFooter.php"); ?>



