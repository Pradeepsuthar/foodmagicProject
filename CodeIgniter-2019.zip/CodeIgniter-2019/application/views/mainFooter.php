<!-- Footer -->
<section id="footer">
    <div class="container">
    <div class="col-12 text-center mb-5">
      <img src="<?php echo base_url('assets/images/foodmagic-logo.png'); ?>" width="250px" height="60px" alt="logo">
    </div>
      <div class="row text-center text-xs-center text-sm-left text-md-left">
        <div class="col-xs-12 col-sm-4 col-md-4">
          <h5 class="text-white">For Restaurants </h5>
          <ul class="list-unstyled quick-links">
            <li><a href="javascript:void();"><i class="fa fa-angle-double-right"></i>Add a Restaurant</a></li>
            <li><a href="javascript:void();"><i class="fa fa-angle-double-right"></i>Business Owner Guidelines</a></li>
            <li><a href="javascript:void();"><i class="fa fa-angle-double-right"></i>Products for Businesses</a></li>
            <li><a href="javascript:void();"><i class="fa fa-angle-double-right"></i>How to become our Partner</a></li>
            <li><a href="javascript:void();"><i class="fa fa-angle-double-right"></i>Careers</a></li>
          </ul>
        </div>
        <div class="col-xs-12 col-sm-4 col-md-4">
          <h5 class="text-white">About FOODMAGIC</h5>
          <ul class="list-unstyled quick-links">
            <li><a href="javascript:void();"><i class="fa fa-angle-double-right"></i>CONTACT US</a></li>
            <li><a href="javascript:void();"><i class="fa fa-angle-double-right"></i>ABOUT US</a></li>
            <li><a href="javascript:void();"><i class="fa fa-angle-double-right"></i>PRIVACY POLICY</a></li>
            <li><a href="javascript:void();"><i class="fa fa-angle-double-right"></i>TERMS & CONDITIONS</a></li>
            <li><a href="javascript:void();"><i class="fa fa-angle-double-right"></i>HELP (FAQ'S)</a></li>
          </ul>
        </div>
        <div class="col-xs-12 col-sm-4 col-md-4">
          <h5 class="text-white">Available for</h5>
          <ul class="list-unstyled quick-links">
              <li><a href="javascript:void();"><i class="fa fa-angle-double-right"></i>GITS</a></li>   
          </ul>
        </div>
      </div>
      <!-- <div class="row">
        <div class="col-xs-12 col-sm-12 col-md-12 mt-2 mt-sm-5">
          <h4 class="text-center text-white">SOCIAL LINKS</h4><hr style="background-color:gray">
          <ul class="list-unstyled list-inline social text-center">
            <li class="list-inline-item"><a href="javascript:void();"><i class="fa fa-facebook"></i></a></li>
            <li class="list-inline-item"><a href="javascript:void();"><i class="fa fa-twitter"></i></a></li>
            <li class="list-inline-item"><a href="javascript:void();"><i class="fa fa-instagram"></i></a></li>
            <li class="list-inline-item"><a href="javascript:void();"><i class="fa fa-google-plus"></i></a></li>
            <li class="list-inline-item"><a href="javascript:void();" target="_blank"><i class="fa fa-envelope"></i></a>
            </li>
          </ul>
        </div>
        <hr>
      </div> -->
      <div class="row">
        <div class="col-xs-12 col-sm-12 col-md-12 mt-2 mt-sm-2 text-center">
          <!-- <p class="text-gray"><u><a href="https://www.nationaltransaction.com/">National Transaction
                Corporation</a></u> is a Registered MSP/ISO of Elavon, Inc. Georgia [a wholly owned subsidiary of U.S.
            Bancorp, Minneapolis, MN]</p> -->
          <p class="h6 text-gray" >Copyright &copy; 2019-2020 <a class="text-white ml-2" href="#" target="_blank">foodmagic</a> All Rights Reserved.</p>
        </div>
        <hr>
      </div>
    </div>
  </section>

<!-- //Footer -->