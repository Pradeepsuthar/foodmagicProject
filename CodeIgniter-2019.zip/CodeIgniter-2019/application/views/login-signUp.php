<!-- Sign Up / Login -->
<!-- Modal -->
<div class="modal fade" id="login" role="dialog" aria-labelledby="LoginForm" aria-hidden="true">
	<div class="modal-dialog modal-dialog-centered" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true" style="color: #FFBE0D">&times;</span>
				</button>
			</div>
			<!-- Sign Up -->
			<div class="modal-body" id="registerForm" style="display: none">
				<h3 class="modal-title text-center" style="color: #FFBE0D">Sign Up</h3>
				<hr>
				<form action="#">
					<div class="form-group">
						<input type="text" class="input-filed" id="name" min="2" max="150"
							ondrop="return true;" onpaste="return true;"
							onkeypress="return event.charCode >= 65 && event.charCode <= 90 || event.charCode >= 97 && event.charCode <= 122 || event.charCode == 32" placeholder="Full Name *" required>
						<span id="nameError"></span>
					</div>
					<div class="form-group">
						<input type="text" class="input-filed" placeholder="Mobile Number *" id="mobile" min="1" max="10"
							ondrop="return false;" onpaste="return false;"
							onkeypress="return event.charCode >= 48 && event.charCode <= 57" required>
						<span id="mobileError"></span>
					</div>
					<div class="form-group">
						<input type="email" class="input-filed" placeholder="Email address *" id="email" required>
						<span id="emailError"></span>
					</div>
					<div class="form-group">
						<input type="password" class="input-filed" placeholder="Password *" title="Password must be 4-20 characters" id="pass" minlength="4" required>
						<span id="passError"></span>
					</div>
					<div class="form-group">
						<input type="password" class="input-filed" placeholder="Confirm Password *" title="Confirm Password must be 4-20 characters" id="cpass" minlength="4" required>
						<span id="cpassError"></span>
					</div>
					<div class="form-group form-check">
						<input type="checkbox" class="form-check-input" id="agreements" onclick="submitSuccess()">
						<label class="form-check-label text-gray font-weight-bold" for="agreements">I agree to <a
								href="#">Terms & Conditions</a> & <a href="#">Privacy Policy</a>.</label>
					</div>
					<div class="text-center">
						<button type="submit" class="btn btn menu-custom-btn" id="submit" disabled>Submit</button>
					</div>

					<div class="text-center my-3">
						<span class="my-0">Already have an account?</span><a class="text-decoration-none" href="#" onclick="showLoginForm()">
							Login</a>
					</div>
				</form>
			</div>

			<!-- Login -->
			<div class="modal-body" id="loginForm" style="display: block">
				<h3 class="modal-title text-center" style="color: #FFBE0D">Login</h3>
				<hr>
				<form>
					<div class="form-group">
						<input type="email" class="input-filed" id="email" placeholder="Enter email" required>
					</div>
					<div class="form-group">
						<input type="password" class="input-filed" id="pass" placeholder="Password" required>
					</div>
					<div class="text-center">
						<button type="submit" class="btn btn menu-custom-btn" id="login">Submit</button>
					</div>

					<div class="text-center my-3">
						<span class="my-0">Don't have an account?</span><a class="text-decoration-none" href="#" onclick="showRegisterForm()">
							Register</a><br>
						<a class="text-decoration-none" href="#">Forgot Password ?</a>
					</div>
				</form>
			</div>
		</div>
	</div>
</div>
<!-- //Sign Up / Login -->

<script>
function submitSuccess(){
	var x = document.getElementById("agreements").checked;	
    if(x){
	document.getElementById("submit").removeAttribute("disabled");
	}
	else{
	var btn = document.getElementById("submit");
	var att = document.createAttribute("disabled");
  	btn.setAttributeNode(att);
	}
}
</script>